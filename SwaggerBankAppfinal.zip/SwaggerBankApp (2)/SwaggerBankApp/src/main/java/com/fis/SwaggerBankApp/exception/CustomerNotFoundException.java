package com.fis.SwaggerBankApp.exception;

public class CustomerNotFoundException extends RuntimeException {

	public CustomerNotFoundException(String message) 
    {
        super(message);
    }
	
}