package com.fis.SwaggerBankApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.SwaggerBankApp.exception.AccountNotFoundException;
import com.fis.SwaggerBankApp.model.Account;
import com.fis.SwaggerBankApp.service.AccountService;


@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
    private AccountService accountService;

    @PostMapping("/addAccount")
    public String addAccount(@RequestBody @Validated Account account) {
    	
//    	http://localhost:8080/accounts/addAccount    	
        return accountService.createAccount(account);
    }

    @PutMapping("/updateAccount")
    public String updateAccount(@RequestBody @Validated Account account) {
    	
//    	http://localhost:8080/accounts/updateAccount
        return accountService.updateAccount(account);
    }

    @DeleteMapping("/deleteAccount/{accountId}")
    public String deleteAccount(@PathVariable("accountId") long accountId) throws AccountNotFoundException
    {
    	
//    	http://localhost:8080/accounts/deleteAccount/1
        return accountService.deleteAccount(accountId);
    }

    @GetMapping("/getAccount/{accountId}")
    public Account getAccount(@PathVariable("accountId") long accountId) throws AccountNotFoundException
    {
    	
//    	http://localhost:8080/accounts/getAccount/1
        Account account = accountService.getAccount(accountId);
            return account;
    }

    @GetMapping("/getAllAccounts")
    public List<Account> getAllAccounts() {
    	
//    	http://localhost:8080/accounts/getAllAccounts
        List<Account> accounts = accountService.getAllAccounts();
        return accounts;
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam("accountId") long accountId, @RequestParam("amount") double amount) {
    	
//    	http://localhost:8080/accounts/deposit
    	accountService.depositAmount(accountId, amount);
    	return "Amount of "+amount+" deposited";
    }
    
    @PostMapping("/withdraw")
    public String withdrawAmount(@RequestParam("accountId") long accountId, @RequestParam("amount") double amount) {
    	
//    	http://localhost:8080/accounts/withdraw
    	accountService.withdrawAmount(accountId, amount);
    	return "Amount "+amount+"withdrawn";
    }
    
    @PostMapping("/fundTransfer")
    public String fundTransfer(@RequestParam("fromAccountNumber") long fromAccountNumber, @RequestParam("toAccountNumber") long toAccountNumber, @RequestParam("amount") double amount, @RequestParam("transactionType") String transactionType) {
        
//    	http://localhost:8080/accounts/fundTransfer
    	accountService.fundTransfer(fromAccountNumber, toAccountNumber, amount, transactionType);
        return "Fund of "+ amount+" is transferred";
    }
    
}
