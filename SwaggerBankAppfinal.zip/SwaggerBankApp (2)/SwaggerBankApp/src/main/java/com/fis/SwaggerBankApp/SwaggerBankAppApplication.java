package com.fis.SwaggerBankApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerBankAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerBankAppApplication.class, args);
	}

}
