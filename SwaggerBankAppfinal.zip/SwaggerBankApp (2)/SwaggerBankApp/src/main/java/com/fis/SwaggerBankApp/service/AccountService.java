package com.fis.SwaggerBankApp.service;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.SwaggerBankApp.exception.AccountNotFoundException;
import com.fis.SwaggerBankApp.model.Account;
import com.fis.SwaggerBankApp.model.Transaction;
import com.fis.SwaggerBankApp.repo.AccountRepo;


@Service
@Transactional
public class AccountService{
	
	@Autowired
	AccountRepo arepo;
	@Autowired
	TransactionService tservice;
	
	public String createAccount(Account acct) {
		arepo.save(acct);
		return "Account added successfully";
	}
    
	public Account getAccount(long accountId) throws AccountNotFoundException
    {
    	Optional<Account> optional = arepo.findById(accountId);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new AccountNotFoundException("Account not found for : " + accountId);
		}
        
    }
	public String updateAccount(Account account) {

    	arepo.save(account);
        return "Account updated Successfully";
    }

    
  
    public String deleteAccount(long accountId)
    {
    	Account account = getAccount(accountId);
		
    	arepo.delete(account);
        return "Account Deleted Successfully";
    }
	
	public double getBalance(long accNo) {
		return arepo.displayBalance(accNo);
	}
	
	public List<Account> getAllAccounts() {
        return arepo.findAll();
    }

	public void depositAmount(long accNo, double amount) {
		arepo.deposit(accNo, amount);
		Account a=getAccount(accNo);
		Transaction d= new Transaction(a,a,amount,new Date(),"Deposit");
		tservice.addTransaction(d);
	}

	public void withdrawAmount(long accNo, double amount){
		arepo.withdraw(accNo, amount);
		Account a=getAccount(accNo);
		Transaction w= new Transaction(a,a,amount,new Date(),"Withdraw");
		tservice.addTransaction(w);
	}

	public void fundTransfer(long sender, long receiver, double amount,String transactionType){
		arepo.withdraw(sender, amount);
		arepo.deposit(receiver, amount);
		
		Account a=getAccount(sender);
		Account b=getAccount(receiver);
		Transaction t= new Transaction(a,b,amount,new Date(),transactionType);
		tservice.addTransaction(t);
	}
	
	
}
