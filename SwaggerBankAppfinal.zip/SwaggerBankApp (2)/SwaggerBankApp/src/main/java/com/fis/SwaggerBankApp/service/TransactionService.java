package com.fis.SwaggerBankApp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.SwaggerBankApp.exception.TransactionNotFoundException;
import com.fis.SwaggerBankApp.model.Transaction;
import com.fis.SwaggerBankApp.repo.TransactionRepo;



@Service
@Transactional
public class TransactionService {

	    @Autowired
		private TransactionRepo transactionRepo;
		
		public String addTransaction(Transaction transaction) {
			 
			transactionRepo.save(transaction);
			return "Transaction added Successfully";
		}

		
		public String updateTransaction(Transaction transaction) {
			 
			transactionRepo.save(transaction);
			return "Transaction added Successfully";
		}

		
		public String deleteTransaction(long transactionId) {
			 
			transactionRepo.deleteById(transactionId);
			return "Transaction deleted Successfully";
		}

		
		public Transaction getTransactionById(long transactionId) throws TransactionNotFoundException
		{
			Optional<Transaction> optional = transactionRepo.findById(transactionId);
			if (optional.isPresent()) {
				return optional.get();
			} else {
				throw new TransactionNotFoundException("Transaction not found for : " + transactionId);
			}
		}

	
		public List<Transaction> getAllTransactions() {
			 
			return transactionRepo.findAll();
		}
		
}
