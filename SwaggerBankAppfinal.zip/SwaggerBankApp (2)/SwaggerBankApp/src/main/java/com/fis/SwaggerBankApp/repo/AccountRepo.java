package com.fis.SwaggerBankApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fis.SwaggerBankApp.model.Account;



public interface AccountRepo extends JpaRepository<Account, Long>{
	@Query("select a.balance from Account a where a.id = ?1") 
	public double displayBalance(long accNo);
	
//	deposit	into account
	@Modifying
	@Query("UPDATE Account a SET a.balance = a.balance + :amount WHERE a.id = :accountNo")
	void deposit(@Param("accountNo") long accountId, @Param("amount") double amount);
	
//	withdraw from account
	@Modifying
	@Query("UPDATE Account a SET a.balance = a.balance - :amount WHERE a.id = :accountNo")
	void withdraw(@Param("accountNo") long accountId, @Param("amount") double amount);
	
}
