package com.fis.SwaggerBankApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.SwaggerBankApp.model.Customer;



public interface CustomerRepo extends JpaRepository<Customer, Long> {

}
