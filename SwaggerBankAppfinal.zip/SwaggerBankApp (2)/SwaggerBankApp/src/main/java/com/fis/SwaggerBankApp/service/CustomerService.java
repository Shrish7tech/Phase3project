package com.fis.SwaggerBankApp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.SwaggerBankApp.exception.CustomerNotFoundException;
import com.fis.SwaggerBankApp.model.Customer;
import com.fis.SwaggerBankApp.repo.CustomerRepo;



@Service
@Transactional
public class CustomerService{
	@Autowired
	CustomerRepo crepo;

	public String createCustomer(Customer customer) {
		crepo.save(customer);
		return "Customer Saved Successfully";
	}
	
	public String updateCustomer(Customer customer) {
		// TODO Auto-generated method stub

		crepo.save(customer);
		return "Customer updated successful";
	}

	public String deleteCustomer(long cusid) throws CustomerNotFoundException {
		Optional<Customer> optional =crepo.findById(cusid);
		if (optional.isPresent()) {
			crepo.deleteById(cusid);
			return "Customer with cusid= "+cusid+" deleted successful";
		} else {
			throw new CustomerNotFoundException("Customer Id is invalid...");
		}
	}	
	
	public Customer getCustomerById(long cusId)  {
		// TODO Auto-generated method stub
		Optional<Customer> optional = crepo.findById(cusId);
		return optional.get();
		
	}
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return crepo.findAll();
	}
}

