package com.fis.SwaggerBankApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.SwaggerBankApp.model.Transaction;


public interface TransactionRepo extends JpaRepository<Transaction, Long> {

}
