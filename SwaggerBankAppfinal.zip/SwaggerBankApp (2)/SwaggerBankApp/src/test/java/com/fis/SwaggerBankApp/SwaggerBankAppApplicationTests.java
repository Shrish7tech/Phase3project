package com.fis.SwaggerBankApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerBankAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
