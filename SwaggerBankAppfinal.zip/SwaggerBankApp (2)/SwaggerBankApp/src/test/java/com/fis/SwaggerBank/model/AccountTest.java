package com.fis.SwaggerBank.model;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.fis.SwaggerBankApp.model.Account;
 
 
public class AccountTest {
 
	Account account = new Account();

 
	@Test

	void setAccountPassword() {

		account.setPassword("Shrish@12");

		assertEquals("Shrish@12", account.getPassword());

	}

 
	@Test

	void setAccountTypeTest() {

		account.setAccountType("Current");

		assertEquals("Current", account.getAccountType());

	}
 
 
}